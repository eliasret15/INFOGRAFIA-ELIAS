//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)

func printFullName(firstName:String, middleName:String?, lastName:String)-> String?{
    if let middleName = middleName{   //la constante y la otra la opcional
        return firstName+middleName+lastName

    }else{
return nil    }
}

//printFullName(firstName: "Jose ", middleName: "Elias", lastName: "Retiz")

let fullName = printFullName(firstName: "Marduk", middleName: nil, lastName: "Perez")


if let fullName = fullName{
    print(fullName)
}
