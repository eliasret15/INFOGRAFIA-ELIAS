//
//  ViewController.swift
//  AUTOLAYOUT
//
//  Created by Macbook on 4/8/19.
//  Copyright © 2019 DanielHdzG. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

