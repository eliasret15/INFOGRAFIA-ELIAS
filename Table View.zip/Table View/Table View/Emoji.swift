//
//  Emoji.swift
//  Table View
//
//  Created by Macbook on 5/6/19.
//  Copyright © 2019 Elias. All rights reserved.
//

class Emoji{
    
    var symbol: String
    var name: String
    var description: String
    var usage: String
    
    init(symbol: String, name:String, desciption: String , usage: String){ //inicializador instancia con sus valores
        self.symbol = symbol
        self.name = name
        self.description = desciption
        self.usage = usage
    }
}
