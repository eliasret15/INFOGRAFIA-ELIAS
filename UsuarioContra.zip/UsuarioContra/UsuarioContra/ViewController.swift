//
//  ViewController.swift
//  UsuarioContra
//
//  Created by Macbook on 4/11/19.
//  Copyright © 2019 DanielHdzG. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var username: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //navigationItem.title = "usuario"
    }

}

