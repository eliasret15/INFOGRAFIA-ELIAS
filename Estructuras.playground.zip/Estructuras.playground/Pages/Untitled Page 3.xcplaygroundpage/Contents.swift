//: [Previous](@previous)

import Foundation

struct Temperature {
    static var boilingPoint = 100//tiene static y hay que ver como llegar a el
    var celsius: Double
    static func hello (){
        print ("Hola mi bpoiling point es: \(boilingPoint)")
    }
}

var instanciaTemp1 = Temperature(celsius : 200.0)
Temperature.boilingPoint
var instanciaTem2 = Temperature(celsius: 400.0)

/*Temperature.boilingPoint = 5000 //para poder modificar el boiling point por el static
Temperature.hello()//se puede modificar desde el hello
*/
var instanciaTem3 = instanciaTem2


//: [Next](@next)
