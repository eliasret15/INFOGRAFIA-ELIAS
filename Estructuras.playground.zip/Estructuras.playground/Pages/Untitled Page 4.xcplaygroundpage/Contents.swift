//: [Previous](@previous)

import Foundation

struct Odometer {
    var count: Int = 0
   mutating func increment(){ //mutating para que no haya problema con el count y no lo haga static
        count += 1
    }
}

var instanciaOdometro = Odometer(count: 10)

for _ in 1...10 {
    instanciaOdometro.increment()
    print(instanciaOdometro.count)
}
//: [Next](@next)




//OTRO PROGRAMA


struct Temperatura{
    var celsius: Double
    var fahrenheit: Double
    var kelvin:Double
    
    init (celsius:Double){
        self.celsius = celsius
        fahrenheit = celsius*1.8+32
        kelvin = celsius+273.15
    }
    
    init (fahrenheit:Double){
        self.fahrenheit = fahrenheit
        celsius = (fahrenheit-32)/1.8
        kelvin = celsius + 273.15
    }
    
    init (kelvin:Double){
        self.kelvin = kelvin
        celsius = kelvin - 273.15
        fahrenheit = celsius*1.8 + 32
    }
}
