//: [Previous](@previous)

import Foundation
//OBSERVADORES DE PROPIEDAD
struct StepCounter{
    var totalSteps : Int = 0 {//ya esta definido el valor inicial no pide parametro
        willSet{ //APENAS VA A CAMBIAR EL VALOR
            print("About to set totalSteps to \(newValue)")
        }
        didSet{//YA CAMBIO EL VALOR
            if (totalSteps > oldValue){
                print("Added \(totalSteps - oldValue) steps")
            }//OLD VALUE Y NEW VALUE SON PROPIEDADES QUE REGALAN LOS ONSERVADORES
        }
    }
}
var pasosElias = StepCounter()
pasosElias.totalSteps
pasosElias.totalSteps = 10
pasosElias.totalSteps
//: [Next](@next)
