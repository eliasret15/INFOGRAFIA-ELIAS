import UIKit

struct Temperatura {
    var celsius:Double
    
   /* init (celsius:Double){// init es inicializar
        self.celsius = celsius // self nos dice que usará el celsius de arriba
    }*/
    var fahrenheit:Double{//ligar propiedades
        return celsius*1.8+32
    }
    
}

var instanciaTemperatura = Temperatura (celsius: 10.0) //pide la variable de fahrenheit
//instanciaTemperatura.celsius
instanciaTemperatura.fahrenheit
instanciaTemperatura.celsius=0
instanciaTemperatura.fahrenheit
