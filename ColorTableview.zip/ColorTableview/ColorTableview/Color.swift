//
//  Color.swift
//  ColorTableview
//
//  Created by Macbook on 5/8/19.
//  Copyright © 2019 Elias. All rights reserved.
//

import Foundation

struct Color{
    var Nombre: String
    var Composicion:[String]?
}
