//
//  ViewController.swift
//  ColorTableview
//
//  Created by Macbook on 5/8/19.
//  Copyright © 2019 Elias. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

