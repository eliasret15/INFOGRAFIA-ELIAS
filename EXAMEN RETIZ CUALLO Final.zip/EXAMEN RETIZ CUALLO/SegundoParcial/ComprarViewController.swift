//
//  ReservarViewController.swift
//  SegundoParcial
//
//  Copyright © 29/04/2019 Guest User. All rights reserved.
//

import UIKit

class ComprarViewController: UIViewController {
    
    @IBOutlet weak var camisasTextLabel1: UILabel!
    @IBOutlet weak var tazasLabel2: UILabel!
    @IBOutlet weak var cuponText: UITextField!
    @IBOutlet weak var stepper1: UIStepper!
    @IBOutlet weak var stepper2: UIStepper!
    
    
    let cuponReal = "BrunoCool"
    var total: Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func stepper1Change(_ sender: UIStepper) {
        camisasTextLabel1.text = "\(Int(sender.value))"
    }
    
    @IBAction func stepper2Change(_ sender: UIStepper) {
        tazasLabel2.text = "\(Int(sender.value))"
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let total = total else {return}
        if let destino = segue.destination as? DescuentoViewController {
            destino.total = total
        }
        
        
    }
    
    
    @IBAction func continuarButton(_ sender: UIButton) {
        let cantidadPlayeras = stepper1.value
        let cantidadSudadera = stepper2.value
        let cuponReal = "BrunoCool"
        var cobro = 0.0
        
        if cantidadPlayeras > 0.0 {
            cobro = 300.0 * cantidadPlayeras
        }
        
        if cantidadSudadera > 0.0 {
            cobro = 600.0 * cantidadSudadera
        }
        
        if cuponText.text == cuponReal {
            cobro = 0.5 * cobro
        }
        
       
        
        total = cobro
        performSegue(withIdentifier: "total", sender: self)
        
    }
    
    
}
